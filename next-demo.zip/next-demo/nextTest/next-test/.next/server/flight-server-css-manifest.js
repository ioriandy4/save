self.__RSC_CSS_MANIFEST={
  "cssImports": {
    "/Users/yu/code/test/nextTest/next-test/src/app/page.tsx": [
      "/Users/yu/code/test/nextTest/next-test/node_modules/next/font/google/target.css?{\"path\":\"src/app/page.tsx\",\"import\":\"Inter\",\"arguments\":[{\"subsets\":[\"latin\"]}],\"variableName\":\"inter\"}",
      "/Users/yu/code/test/nextTest/next-test/src/app/page.module.css"
    ],
    "/Users/yu/code/test/nextTest/next-test/src/app/layout.tsx": [
      "/Users/yu/code/test/nextTest/next-test/src/app/globals.css"
    ]
  },
  "cssModules": {
    "/Users/yu/code/test/nextTest/next-test/src/app/page": [
      "/Users/yu/code/test/nextTest/next-test/src/app/page.module.css",
      "/Users/yu/code/test/nextTest/next-test/src/app/globals.css"
    ]
  }
}