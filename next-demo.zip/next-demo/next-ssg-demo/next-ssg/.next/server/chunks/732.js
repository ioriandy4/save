exports.id = 732;
exports.ids = [732];
exports.modules = {

/***/ 2070:
/***/ ((module) => {

// Exports
module.exports = {
	"P-index": "home_P-index__hGhd9",
	"img-wrap": "home_img-wrap__ITGII",
	"pic": "home_pic__s7cBq"
};


/***/ }),

/***/ 6732:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/nav/index.js
var nav = __webpack_require__(963);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/common/images/app.png
/* harmony default export */ const app = ({"src":"/_next/static/media/app.7bb412f0.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2UlEQVR42jWOy2rCUBCG53XyVpa6aXctbdrSLoTu+khtBYMaEy+IG43RKBGPB28HRUUTL78zCwc++Pk/mBn6DH1irKfQd15DPxWeOX9xRzI/UcN6CFxTnA5RmcXwZiMUOEsnjnK9mnMXuGjpfqKWY0yMQlNHSYY7cfTGK3P9OtR+g9vowxbfUQM2O8p2Sqm/VFjrKRbGYM5Iri8Usp1ySvdB2fnVA+B4TnABIJwuyT934uidv+Uz5o8fjHcrZo38PMZHr2rsrmeRHXqClWkXncfATQXJLyKJ6Aq328WEu1rzmwAAAABJRU5ErkJggg=="});
// EXTERNAL MODULE: ./src/pages/home/index.module.scss
var index_module = __webpack_require__(2070);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
;// CONCATENATED MODULE: ./src/pages/home/index.js





function Index() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (index_module_default())["P-index"],
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(nav/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "This is Index Page."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (index_module_default())["img-wrap"],
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: app,
                    alt: ""
                })
            })
        ]
    });
}
/* harmony default export */ const home = (Index);


/***/ })

};
;