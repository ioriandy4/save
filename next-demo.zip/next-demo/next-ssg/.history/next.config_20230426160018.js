/** @type {import('next').NextConfig} */
const nextConfig = {
  unoptimized: true,
  output: 'export',
  distDir: 'dist',
}

module.exports = nextConfig
