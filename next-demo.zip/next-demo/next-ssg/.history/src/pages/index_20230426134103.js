import Home from '@/pages/className={pageStyle['p-index']}
function Index () {
    return <Home />
}

export default Index;