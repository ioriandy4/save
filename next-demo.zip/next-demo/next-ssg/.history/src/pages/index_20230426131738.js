import Head from 'next/head'
import pageStyle from './index.module.scss'

export default function Home() {
  return (
    <>
    <Head>
      <title className={pageStyle['p-index']}>My Next App</title>
    </Head>
    <h1>23423423</h1>
    </>
    
  )
}
