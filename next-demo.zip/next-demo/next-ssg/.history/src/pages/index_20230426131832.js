import Head from 'next/head'
import pageStyle from './index.module.scss'

export default function Home() {
  return (
    <>
    <Head>
      <title>My1 Next App</title>
    </Head>
    <h1 className={pageStyle['p-index']}>23423423</h1>
    </>
    
  )
}
