import Head from 'next/head'

export default function Home() {
  return (
    <>
    <Head>
      <title>My Next App</title>
    </Head>
    <h1>23423423</h1>
    </>
    
  )
}
