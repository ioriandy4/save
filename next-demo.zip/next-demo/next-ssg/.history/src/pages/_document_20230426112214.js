import { Html, Head, Main, NextScript } from 'next/document'

export default function Document() {
    return (
        <Html>
            <body>
            <Head>
                <meta name="description" content="Next.js演示项目" />
            </Head>
                <Main />
                <NextScript />
            </body>
        </Html>
    )
}