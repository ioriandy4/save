import Home from '@/pages/index'
function Index () {
    return <Home />
}

export default Index;