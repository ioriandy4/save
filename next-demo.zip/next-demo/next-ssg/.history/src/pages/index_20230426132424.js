import Head from 'next/head'
import pageStyle from './index.module.scss'

export default function Home() {
  return (
    <>
    <Head>
      <title>My1 Next App</title>
    </Head>
    <div className={pageStyle['p-index']}>
      <h1>23423423</h1>
    </div>
    </>
    
  )
}
