import Head from 'next/head'
import pageStyle from './about.module.scss'
import Nav from '@/components/nav'

export default function Home() {
  return (
    <>
    <Head>
      <title>about</title>
    </Head>
    <div className={pageStyle['p-index']}>
        <Nav />
      <h1>I am about page</h1>
    </div>
    </>
    
  )
}
