import Head from 'next/head'
import pageStyle from './about.module.scss'
import Nav from '@/components/nav'
import logo from '@/common/images/1.jpg'

export default function Home() {
  return (
    <>
    <Head>
      <title>about</title>
    </Head>
    <div className={pageStyle['p-index']}>
        <Nav />
        <h1>I am about page1</h1>
        <img src="https://img1.baidu.com/it/u=413643897,2296924942&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1682614800&t=c56f6772982616dc87a557a260e4d2c4" />
    </div>
    </>
    
  )
}
