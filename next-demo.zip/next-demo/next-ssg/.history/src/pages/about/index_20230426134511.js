import Head from 'next/head'
import pageStyle from './index.module.scss'

export default function Home() {
  return (
    <>
    <Head>
      <title>about</title>
    </Head>
    <div className={pageStyle['p-index']}>
      <h1>I am index page</h1>
    </div>
    </>
    
  )
}
