import axios from 'axios'
import Link from 'next/link'
import pageStyle from './profile.module.scss'

function Profile(props) {
    const { data } = props.profileData
    console.log(data);
}