import axios from 'axios'
// import Link from 'next/link'
// import pageStyle from './profile.module.scss'

function Profile(props) {
    const { data } = props.profileData
    console.log(data);
}

export const getStaticProps = async () => {
    const res = await axios({
        method: 'get',
        url: 'https://mon.zijieapi.com/monitor_web/settings/browser-settings?bid=passport_account_api&store=1',
        params: {}
    })
    return {
        props: {
            profileData: res.data
        }
    }
}