import { useRouter } from 'next/router'
import Link from 'next/link'
import styles from './nav.module.scss'

function Nav() {
    const router = useRouter()
    const pathname = router.pathname


    return (
        <div className={styles['nav']}>
            
        </div>
    )
}