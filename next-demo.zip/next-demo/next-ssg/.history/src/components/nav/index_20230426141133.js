import { useRouter } from 'next/router'
import Link from 'next/link'
import styles from './nav.module.scss'