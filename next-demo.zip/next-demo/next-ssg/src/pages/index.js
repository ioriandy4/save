import Home from '@/pages/home'
function Index() {
    return <Home />
}
export default Index