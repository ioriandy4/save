import Head from 'next/head'
import pageStyle from './index.module.scss'
import Nav from 'src1/components/nav'

export default function Home() {
  return (
    <>
    <Head>
      <title>My Next App</title>
    </Head>
    <div className={pageStyle['p-index']}>
      <Nav />
      <h1>I am index page</h1>
    </div>
    </>
    
  )
}
