import Home from 'src1/pages/index/index.js'
function Index () {
    return <Home />
}

export default Index;