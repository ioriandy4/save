import { useRouter } from 'next/router'
import Link from 'next/link'
import styles from './nav.module.scss'

function Nav() {
    return null;
    // const router = useRouter()
    // const pathname = router.pathname


    // return (
    //     <div className={styles['nav']}>
    //         <Link href = '/'>
    //             <div className={styles['tab'] + (pathname === '/' ? ' ' + styles['current'] : '')}>
    //                 Home
    //             </div>
    //         </Link>
    //         <Link href = '/about'>
    //             <div className={styles['tab'] + (pathname === '/about' ? ' ' + styles['current'] : '')}>
    //                 About
    //             </div>
    //         </Link>
    //     </div>
    // )
}

export default Nav;