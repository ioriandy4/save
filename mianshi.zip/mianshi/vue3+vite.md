# vite + vue3
## vite
- vite介绍  [vite 介绍](https://cn.vitejs.dev/guide/why.html)
   - 介绍
     
     vue3官网提供两种安装vue3的方式，一种是vue-cli，另一种是vite，vite是类似与webpack的打包编译工具
     >为什么选 Vite
     >  #### 现实问题
     >  在浏览器支持 ES 模块之前，JavaScript 并没有提供的原生机制让开发者以模块化的方式进行开发。这也正是我们对 “打包” 这个概念熟悉的原因：使用工具抓取、处理并将我们的源码模块串联成可以在浏览器中运行的文件。
     >   时过境迁，我们见证了诸如 webpack、Rollup 和 Parcel 等工具的变迁，它们极大地改善了前端开发者的开发体验。
     > 
     >   然而，当我们开始构建越来越大型的应用时，需要处理的 JavaScript 代码量也呈指数级增长。包含数千个模块的大型项目相当普遍。我们开始遇到性能瓶颈 —— 使用 JavaScript 开发的工具通常需要很长时间（甚至是几分钟！）才能启动开发服务器，即使使用 HMR，文件修改后的效果也需要几秒钟才能在浏览器中反映出来。如此循环往复，迟钝的反馈会极大地影响开发者的开发效率和幸福感。
     > 
     >   Vite 旨在利用生态系统中的新进展解决上述问题：浏览器开始原生支持 ES 模块，且越来越多 JavaScript 工具使用编译型语言编写。
     > 
     >   #### 缓慢的服务器启动
     >   当冷启动开发服务器时，基于打包器的方式启动必须优先抓取并构建你的整个应用，然后才能提供服务。
     > 
     >   Vite 通过在一开始将应用中的模块区分为 依赖 和 源码 两类，改进了开发服务器启动时间。
     > 
     >   依赖：大多为在开发时不会变动的纯 JavaScript。一些较大的依赖（例如有上百个模块的组件库）处理的代价也很高。依赖也通常会存在多种模块化格式（例如 ESM 或者 CommonJS）。
     > 
     >   Vite 将会使用 esbuild 预构建依赖。Esbuild 使用 Go 编写，并且比以 JavaScript 编写的打包器预构建依赖快 10-100 倍。请求一个多依赖的资源，只发送一个请求
     > 
     >   源码：通常包含一些并非直接是 JavaScript 的文件，需要转换（例如 JSX，CSS 或者 Vue/Svelte 组件），时常会被编辑。同时，并不是所有的源码都需要同时被加载（例如基于路由拆分的代码模块）。
     > 
     >   Vite 以 原生 ESM 方式提供源码。这实际上是让浏览器接管了打包程序的部分工作：Vite 只需要在浏览器请求源码时进行转换并按需提供源码。根据情景动态导入代码，即只在当前屏幕上实际使用时才会被处理。
     >   基于打包器的开发服务器
     >   基于 ESM 的开发服务器
     > 
     > ![blockchain](./vite介绍1.PNG "")
     > 
     > ![blockchain](./vite介绍2.PNG "")
     >   #### 缓慢的更新
     >   基于打包器启动时，重建整个包的效率很低。原因显而易见：因为这样更新速度会随着应用体积增长而直线下降。
     >   一些打包器的开发服务器将构建内容存入内存，这样它们只需要在文件更改时使模块图的一部分失活[1]，但它也仍需要整个重新构建并重载页面。这样代价很高，并且重新加载页面会消除应用的当前状态，所以打包器支持了动态模块热重载（HMR）：允许一个模块 “热替换” 它自己，而不会影响页面其余部分。这大大改进了开发体验 —— 然而，在实践中我们发现，即使采用了 HMR 模式，其热更新速度也会随着应用规模的增长而显著下降。
     > 
     >   在 Vite 中，HMR 是在原生 ESM 上执行的。当编辑一个文件时，Vite 只需要精确地使已编辑的模块与其最近的 HMR 边界之间的链失活[1]（大多数时候只是模块本身），使得无论应用大小如何，HMR 始终能保持快速更新。例如依赖链为a.js - b.js -c.js - d.js，如果改变d.js，只会更新c.js和d.js
     > 
     >   Vite 同时利用 HTTP 头来加速整个页面的重新加载（再次让浏览器为我们做更多事情）：源码模块的请求会根据 304 Not Modified 进行协商缓存，而依赖模块请求则会通过 Cache-Control: max-age=31536000,immutable 进行强缓存，因此一旦被缓存它们将不需要再次请求。
     > 
     >   一旦你体验到 Vite 的神速，你是否愿意再忍受像曾经那样使用打包器开发就要打上一个大大的问号了。
     >   #### 为什么生产环境仍需打包
     >   尽管原生 ESM 现在得到了广泛支持，但由于嵌套导入会导致额外的网络往返，在生产环境中发布未打包的 ESM 仍然效率低下（即使使用 HTTP/2）。为了在生产环境中获得最佳的加载性能，最好还是将代码进行 tree-shaking、懒加载和 chunk 分割（以获得更好的缓存）。
     > 
     >   要确保开发服务器和生产环境构建之间的最优输出和行为一致并不容易。所以 Vite 附带了一套 构建优化 的 构建命令，开箱即用。
     > 
     >   #### 为何不用 ESBuild 打包？
     >   虽然 esbuild 快得惊人，并且已经是一个在构建库方面比较出色的工具，但一些针对构建 应用 的重要功能仍然还在持续开发中 —— 特别是代码分割和 CSS 处理方面。就目前来说，Rollup 在应用打包方面更加成熟和灵活。尽管如此，当未来这些功能稳定后，我们也不排除使用 esbuild 作为生产构建器的可能。


   - 创建项目
     ```
     npm init vite <project-name>
     cd <project-name>
     npm install
     npm run dev
     ```
   - 命令介绍
     ```
     "dev": "vite",
     "build": "vite build",
     "serve": "vite preview"
     ```
   - 请求文件介绍
     ![blockchain](./请求文件.PNG "")
   - 参数介绍 vite.config.js为配置文件
     - root 项目根目录（index.html 文件所在的位置）。可以是一个绝对路径，或者一个相对于该配置文件本身的相对路径
     - base 开发或生产环境服务的公共基础路径,给请求的资源加前缀
     - mode 'development'（开发模式），'production'（生产模式）,通过import.meta.env.MODE获取标识
     - define 定义全局常量替换方式。其中每项在开发环境下会被定义在全局，而在构建时被静态替换
     - publicDir 作为静态资源服务的文件夹，直接请求根目录下的资源时查找的路径
     - resolve.alias 定义路径别名
   - vite和vue2
     需要按照插件 vite-plugin-vue2
       ```js
        import { defineConfig } from 'vite'
        const { createVuePlugin } = require('vite-plugin-vue2')
        export default defineConfig({
            mode: 'development',
            resolve: {
                alias: {
                },
                extensions: ['.mjs', '.js', '.ts', '.jsx', '.tsx', '.json', '.vue']
            },
            plugins: [createVuePlugin()]
        })
       ```
      编译速度对比
     
      webpack
     
      ![blockchain](./agc编译速度对比1.PNG "")
     
      vite
     
      ![blockchain](./agc编译速度对比2.PNG "")
- vite实现
    - 浏览器原始 es imports
      - esimport-demo
        
        ```html
        <!DOCTYPE html>
        <html lang="en">
        
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
        </head>
        
        <body>
        <p>index</p>
        <script type="module">
            import { str } from './helper.js';
            console.log(str);
        </script>
        </body>
        ```
    - 服务端实现 接受文件并解析
      - vite-mini
    
        ```js
        const fs = require('fs')
        const path = require('path')
        const Koa = require('koa')
        const compilerSfc = require('@vue/compiler-sfc') // .vue
        const compilerDom = require('@vue/compiler-dom') // 模板
        
        const app = new Koa()
        function rewriteImport(content){
          return content.replace(/from ['|"]([^'"]+)['|"]/g, function(s0,s1){
            // . ../ /开头的，都是相对路径
            if(s1[0]!=='.'&& s1[1]!=='/'){
              return `from '/@modules/${s1}'`
            }else{
              return s0
            }
          })
        }
        
        app.use(async ctx=>{
          const {request:{url,query} } = ctx
          // 首页
          if(url=='/'){
            ctx.type="text/html"
            let content = fs.readFileSync('./index.html','utf-8')
            content = content.replace('<script ',`
              <script>
                window.process = {env:{ NODE_ENV:'dev'}}
              </script>
              <script 
            `)
            ctx.body = content
          }else if(url.endsWith('.js')){
            // js文件
            const p = path.resolve(__dirname,url.slice(1))
            ctx.type = 'application/javascript'
            const content = fs.readFileSync(p,'utf-8')
            ctx.body = rewriteImport(content)
          }else if(url.endsWith('.css')){
            const p = path.resolve(__dirname,url.slice(1))
            const file = fs.readFileSync(p,'utf-8')
            const content = `
            const css = "${file.replace(/\n/g,'')}"
            let link = document.createElement('style')
            link.setAttribute('type', 'text/css')
            document.head.appendChild(link)
            link.innerHTML = css
            export default css
            `
            ctx.type = 'application/javascript'
            ctx.body = content
          }else if(url.startsWith('/@modules/')){
            // 这是一个node_module里的东西
            const prefix = path.resolve(__dirname,'node_modules',url.replace('/@modules/',''))
            const module = require(prefix+'/package.json').module
            const p = path.resolve(prefix,module)
            const ret = fs.readFileSync(p,'utf-8')
            ctx.type = 'application/javascript'
            ctx.body = rewriteImport(ret)
          }else if(url.indexOf('.vue')>-1){
            // vue单文件组件
            const p = path.resolve(__dirname, url.split('?')[0].slice(1))
            const {descriptor} = compilerSfc.parse(fs.readFileSync(p,'utf-8'))
        
            if(!query.type){
              ctx.type = 'application/javascript'
              // 借用vue自导的compile框架 解析单文件组件，其实相当于vue-loader做的事情
              // 解析的内容赋值给对象的render
              ctx.body = `
          ${rewriteImport(descriptor.script.content.replace('export default ','const __script = '))}
          import { render as __render } from "${url}?type=template"
          __script.render = __render
          export default __script
              `
            }else if(query.type==='template'){
              // 模板内容
              const template = descriptor.template
              // 要在server端吧compiler做了
              const render = compilerDom.compile(template.content, {mode:"module"}).code
              ctx.type = 'application/javascript'
        
              ctx.body = rewriteImport(render)
            }
        
          }
        })
        
        app.listen(3001, ()=>{
          console.log('听我口令，3001端口，起~~')
        })
        ```
        
        html部分
        ```html
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <link rel="icon" href="/favicon.ico" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Vite App</title>
        </head>
        <body>
          <div id="app"></div>
          <script type="module" src="/src/main.js"></script>
        </body>
        </html>

        ```
    
  
## vue3
   - vue3介绍  [vue3 中文文档](https://v3.cn.vuejs.org/) 
   - 亮点
      - Performance（性能提升，Vue3.0相比Vue2.x在性能上提升了1.2~2倍）
           - 打包大小减少41%
           - 初次渲染快55%, 更新渲染快133%
          
             ![blockchain](./性能对比1.PNG "")
             ![blockchain](./性能对比2.PNG "")
           - 内存减少54%
           - 使用Proxy代替defineProperty实现数据响应式
              - object.defineProperty的缺陷
                - Object.defineProperty对新增属性需要手动进行Observe，proxy可以拦截到对象的新增属性做处理，通过set钩子
                - Object.defineProperty只能劫持对象的属性，而Proxy是直接代理对象，由于是使用递归遍历对象，使用 Object.defineProperty 劫持对象的属性，如果遍历的对象层级比较深，花的时间比较久，甚至有性能的问题
                - 对数组也可以拦截，不用手动去做对象处理
              - proxy介绍
              
               对于 proxy ，在 mdn 上的描述是： 对象用于定义基本操作的自定义行为（如属性查找、赋值、枚举、函数调用等） 简单来说就是，可以在对目标对象设置一层拦截。无论对目标对象进行什么操作，都要经过这层拦截，proxy提供十多种拦截的API
               ```js
               // let p = new Proxy(target, handler);
               // target ：需要使用Proxy包装的目标对象（可以是任何类型的对象，包括原生数组，函数，甚至另一个代理）。
               // handler: 一个对象，其属性是当执行一个操作时定义代理的行为的函数(可以理解为某种触发器)。具体的handler相关函数请查阅官网
               const proxy = new Proxy(xiaowang, {
                    get(target,key) {
                        if(key === 'a') {
                            return 'xxx'
                        }
                    }
                })
           - 重写虚拟DOM的实现
             - PatchFlag：在Vue3.0中，只有带PatchFlag的这些node会被真正的追踪，也就是说在后续更新的过程中，Vue会知道静态节点不用管，只需要追踪带有PatchFlag的节点
             ```js
                 <div>
                    <span>static</span>
                    <span :id="hello" class="bar">{{ msg }}   </span>
                </div>
               
                // 编译后的代码
                import { createVNode as _createVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createBlock as _createBlock } from "vue"
                export function render(_ctx, _cache) {
                    return (_openBlock(), _createBlock("div", null, [
                        _createVNode("span", null, "static"),
                        _createVNode("span", {
                        id: _ctx.hello,
                        class: "bar"
                        }, _toDisplayString(_ctx.msg), 9 /* TEXT, PROPS */, ["id"])
                    ]))
                }
             ```
             - 事件监听缓存：cacheHandlers
           - Tree-Shaking

      - Tree shaking support（按需打包模块）

        vue3中的核心api都支持了tree-shaking，这些api都是通过包引入的方式而不是直接在实例化时就注入，只会对使用到的功能或特性进行打包（按需打包），这意味着更多的功能和更小的体积
        ```js
        // vue2
        import Vue from 'vue'
        import App from './App.vue'
        
        new Vue({
        render: h => h(App)
        }).$mount('#app')
        ```

        ```js
        // vue3
        import { createApp } from 'vue';
        import App from './App.vue'

        createApp(App).mount('#app')
        ```
        
      - Better TypeScript support（更好的TS代码支持）
        
        ```js
        // vue2
        // 要用 vue-class-component 强化 vue 组件，让 Script 支持 TypeScript 装饰器
        // 用 vue-property-decorator 来增加更多结合 Vue 特性的装饰器
        @Component({
            components:{ componentA, componentB},
        })
        export default class Parent extends Vue{
            @Prop(Number) readonly propA!: number | undefined
            @Prop({ default: 'default value' }) readonly propB!: string
            @Prop([String, Boolean]) readonly propC!: string | boolean | undefined
            
            // data信息
            message = 'Vue2 code style'
            
            // 计算属性
            private get reversedMessage (): string[] {
                return this.message.split(' ').reverse().join('')
            }
            
            // method
            public changeMessage (): void {
                this.message = 'Good bye'
            }
        }
        ```
        
        ```js
        // vue3
        interface Student {
            name: string
            class?: string
            age: number
        }
        
        export default {
            props: {
                success: { type: String },
                callback: {
                    type: Function as PropType<() => void>
                }
                student: {
                    type: Object as PropType<Student>,
                    required: true
                }
            }
            setup() {
                const student = reactive<Student>({ name: 'a', age: 16 })
            }
        }
        ```
      - Custom Renderer API（自定义渲染API）
        
        在vue3中允许用户自定义目标渲染平台，以往的版本中目标渲染被局限于浏览器dom平台，而现在可以把 vue 的开发模型扩展到其他平台
        ```html
        <!DOCTYPE html>
        <html lang="en">
        
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
        </head>
        
        <body>
        <div id="app">
        </div>
        
        <script type="text/x-template" id="chart">
            <bar-chart :data="chartData"></bar-chart>
        </script>
        
        <script src="D:\file\培训\vue3+vite\vite-demo2\node_modules\vue\dist\vue.global.js"></script>
        <script>
            const { createRenderer } = Vue
            let canvas = document.createElement('canvas')
            canvas.width = window.innerWidth
            canvas.height = window.innerHeight
            const ctx = canvas.getContext('2d')
            const renderer = createRenderer({
                    createElement(tag) {
                        return { tag }
                    },
                    patchProp(el, key, prevValue, nextValue) {
                        el[key] = nextValue
                    },
                    insert(child, parent) {
                        console.log('child', child);
                        console.log('parent', parent);
                        if (parent.nodeType === 1) {
                            draw(child)
                        }
                    }
            })
        
            // 画画的逻辑
            const draw = (el, noClear) => {
                // 清空画布
                if (!noClear) {
                    ctx.clearRect(0, 0, canvas.width, canvas.height)
                }
                if (el.tag == 'bar-chart') {
                    const { data } = el;
                    const barWidth = canvas.width / 10,
                        gap = 20,
                        paddingLeft = (data.length * barWidth + (data.length - 1) * gap) / 2,
                        paddingBottom = 10;
                    data.forEach(({ title, count, color }, index) => {
                        const x = paddingLeft + index * (barWidth + gap)
                        const y = canvas.height - paddingBottom - count
                        ctx.fillStyle = color
                        ctx.fillRect(x, y, barWidth, count)
                    });
                }
                el.childs && el.childs.forEach(child => draw(child, true));
            }
        
            function createCanvasApp(App) {
                const app = renderer.createApp(App)
                const mount = app.mount
                app.mount = function (sel) {
                    document.querySelector(sel).appendChild(canvas)
                    mount(canvas) // 内容挂在到canvas
                }
                return app
            }
        
            createCanvasApp({
                template: '#chart', // template模板
                data() {
                    return {
                        chartData: [
                            { title: "黑铁", count: 260, color: "yellow" },
                            { title: "⻘铜", count: 200, color: "brown" },
                            { title: "钻石", count: 300, color: "pink" },
                            { title: "星耀", count: 100, color: "purple" },
                            { title: "王者", count: 50, color: "gold" }
                        ]
                    }
                },
            }).mount('#app')
        
        </script>
        </body>
        
        </html>
        ```
      - Fragment
        
        在书写vue2时，由于组件必须只有一个根节点，很多时候会添加一些没有意义的节点用于包裹。Fragment组件就是用于解决这个问题的（这和React中的Fragment组件是一样的）
        ```html
        // vue2
        <template>
          <div>
              <header>...</header>
              <main v-bind="$attrs">...</main>
              <footer>...</footer>
          </div>
        </template>
        
        <script>
        export default {};
        </script>
        ```

        ```html
        // vue3
        <template>
          <header>...</header>
              <main v-bind="$attrs">...</main>
          <footer>...</footer>
        </template>
        
        <script>
        export default {};
        </script>
        ```

        ```js
        // vue3
        import { defineComponent, h, Fragment } from 'vue';
        export default defineComponent({
            render() {
            return h(Fragment, {}, [
                h('header', {}, ['...']),
                h('main', {}, ['...']),
                h('footer', {}, ['...']),
            ]);
            }
        });
        ```
      - Teleport
        
        Teleport其实就是React中的Portal。Portal 提供了一种将子节点渲染到存在于父组件以外的 DOM 节点的优秀的方案。一个 portal 的典型用例是当父组件有 overflow: hidden 或 z-index 样式时，但你需要子组件能够在视觉上“跳出”其容器。例如，对话框、悬浮卡以及提示框。
        ```html
        /* App.vue */
        <template>
            <div>123</div>
            <Teleport to="#container">
                Teleport
            </Teleport>
        </template>
        
        <script>
        import { defineComponent } from "vue";
        
        export default defineComponent({
            setup() {}
        });
        </script>
        
        /* index.html */
        <div id="app"></div>
        <div id="container"></div>
        ```
      - Suspense
        
        和React中的Supense一样,Suspense 让你的组件在渲染之前进行“等待”，并在等待时显示 fallback 的内容
        ```html
        // App.vue
        <template>
            <Suspense>
                <template #default>
                    <AsyncComponent />
                </template>
                <template #fallback>
                    Loading...
                </template>
            </Suspense>
        </template>
        
        <script lang="ts">
        import { defineComponent } from "vue";
        import AsyncComponent from './AsyncComponent.vue';
        
        export default defineComponent({
            name: "App",
            
            components: {
                AsyncComponent
            }
        });
        </script>
        
        // AsyncComponent.vue
        <template>
        <div>Async Component</div>
        </template>
        
        <script lang="ts">
        import { defineComponent } from "vue";
        
        const sleep = () => {
            return new Promise(resolve => setTimeout(resolve, 1000));
        };
        
        export default defineComponent({
            async setup() {
                await sleep();
            }
        });
        </script>
        ```
      - Composition API（组合API）
        - optionsApi 和 compositionApi
          
          ![blockchain](./compositionapi.PNG "")
        - setup

          setup 函数也是 Composition API 的入口函数，我们的变量、方法都是在该函数里定义的
            ```html
            <template>
              <div id="app">
                  <p>{{ number }}</p>
                  <button @click="add">增加</button>
              </div>
            </template>
            
            <script>
            // 1. 从 vue 中引入 ref 函数
            import {ref} from 'vue'
            export default {
              name: 'App',
              setup() {
                  // 2. 用 ref 函数包装一个响应式变量 number
                  let number = ref(0)
            
                  // 3. 设定一个方法
                  function add() {
                      // number是被ref函数包装过了的，其值保存在.value中
                      number.value ++
                  }
            
                  // 4. 将 number 和 add 返回出去，供template中使用
                  return {number, add}
              }
              
            }
            </script>

            ```
        - 生命周期

          |  vue2   | vue3  |
          |  ----  | ----  |
          | beforeCreate  | setup |
          | created  | setup |
          | beforeMount  | onBeforeMount |
          | mounted  | onMounted |
          | beforeUpdate  | onBeforeUpdate |
          | updated  | onUpdated |
          | beforeDestory  | onBeforeUnmount |
          | destoryed  | onUnmounted |
    
            ```html
            <template>
              <div id="app"></div>
            </template>
            
            <script>
            // 1. 从 vue 中引入 多个生命周期函数
            import {onBeforeMount, onMounted, onBeforeUpdate, onUpdated, onBeforeUnmount, unMounted} from 'vue'
            export default {
              name: 'App',
              setup() {
                  onBeforeMount(() => {
                      // 在挂载前执行某些代码
                  })
            
                  onMounted(() => {
                      // 在挂载后执行某些代码
                  })
            
                  onBeforeUpdate(() => {
                      // 在更新前前执行某些代码
                  })
            
                  onUpdated(() => {
                      // 在更新后执行某些代码
                  })
            
                  onBeforeUnmount(() => {
                      // 在组件销毁前执行某些代码
                  })
            
                  unMounted(() => {
                      // 在组件销毁后执行某些代码
                  })
            
                  return {}
              }
              
            }
            </script>
            ```
        
        - reactive
          
          reactive 方法是用来创建一个响应式的数据对象
    
            ```html
            <template>
              <div id="app">
                <!-- 4. 访问响应式数据对象中的 count  -->
                {{ state.count }}
              </div>
            </template>
            
            <script>
            // 1. 从 vue 中导入 reactive 
            import {reactive} from 'vue'
            export default {
              name: 'App',
              setup() {
                  // 2. 创建响应式的数据对象
                  const state = reactive({count: 3})
            
                  // 3. 将响应式数据对象state return 出去，供template使用
                  return {state}
              }
            }
            </script>
            ```
        
        - ref

          ref 就是通过 reactive 包装了一个对象 ，然后是将值传给该对象中的 value 属性
          
          基本类型值（String 、Nmuber 、Boolean 等）或单值对象（类似像 {count: 3} 这样只有一个属性值的对象）使用 ref
        引用类型值（Object 、Array）使用 reactive
    
          ```html
            <script>
                import {ref, reactive} from 'vue'
                export default {
                name: 'App',
                setup() {
                let num = ref(10)
                let num2 = reactive({v: 100})
                console.log(num2.value); // 10
                console.log(num3); // {v: 100}
                
                }
            </script>
          ```
          
        - toRef

          可以用来为源响应式对象上的某个 property 新创建一个 ref。然后，ref 可以被传递，它会保持对其源 property 的响应式连接
    
            ```html
            <script>
                // 1. 导入 toRef
                import {toRef} from 'vue'
                export default {
                setup() {
                const obj = {count: 3}
                // 2. 将 obj 对象中属性count的值转化为响应式数据
                const state = toRef(obj, 'count')
                
                        // 3. 将toRef包装过的数据对象返回供template使用
                        return {state}
                    }
                }
            </script>
            ```
          
        - toRefs 可以直接用于整个对象
    
          ```html
            <script>
                // 1. 导入 toRefs
                import {toRefs} from 'vue'
                export default {
                setup() {
                const obj = {
                name: '前端印象',
                age: 22,
                gender: 0
                }
                // 2. 将 obj 对象中属性count的值转化为响应式数据
                const state = toRefs(obj)
                
                        // 3. 打印查看一下
                        console.log(state)
                    }
                }
            </script>
          ```
            
        - shallowReactive  浅层的 reactive
          ```html
            <script>
                import {shallowReactive} from 'vue'
                export default {
                    setup() {
                        const obj = {
                            a: 1,
                            first: {
                                    b: 2,
                                second: {
                                    c: 3
                                }
                            }
                        }
                        
                        const state = shallowReactive(obj)
                
                        console.log(state)
                        console.log(state.first)
                        console.log(state.first.second)
                    }
                }
            </script>
          ```
        - shallowRef  浅层的 ref
            
          ```html
            <template>
                <p>{{ state.a }}</p>
                <p>{{ state.first.b }}</p>
                <p>{{ state.first.second.c }}</p>
                <button @click="change1">改变1</button>
                <button @click="change2">改变2</button>
            </template>
            
            <script>
            import {shallowRef} from 'vue'
            export default {
                setup() {
                    const obj = {
                        a: 1,
                        first: {
                            b: 2,
                            second: {
                                c: 3
                            }
                        }
                    }
            
                    const state = shallowRef(obj)
                    console.log(state);
            
                    function change1() {
                        // 直接将state.value重新赋值
                        state.value = {
                            a: 7,
                            first: {
                                b: 8,
                                second: {
                                    c: 9
                                }
                            }
                        }
                    }
            
                    function change2() {
                        state.value.first.b = 8
                        state.value.first.second.c = 9
                        console.log(state);
                    }
            
                    return {state, change1, change2}
                }
            }
            </script>
          ```
        - toRaw  toRaw 方法是用于获取 ref 或 reactive 对象的原始数据的
            
          ```html
            <script>
                import {reactive, toRaw} from 'vue'
                export default {
                setup() {
                const obj = {
                name: '前端印象',
                age: 22
                }
                
                        const state = reactive(obj)	
                        const raw = toRaw(state)
                
                        console.log(obj === raw)   // true
                    }
                }
            </script>
          ```
        - markRaw  markRaw 方法可以将原始数据标记为非响应式的，即使用 ref 或 reactive 将其包装，仍无法实现数据响应式
            
          ```html
          <template>
                <p>{{ state.name }}</p>
                <p>{{ state.age }}</p>
                <button @click="change">改变</button>
            </template>
            
            <script>
            import {reactive, markRaw} from 'vue'
            export default {
                setup() {
                    const obj = {
                        name: '前端印象',
                        age: 22
                    }
                    // 通过markRaw标记原始数据obj, 使其数据更新不再被追踪
                    const raw = markRaw(obj)   
                    // 试图用reactive包装raw, 使其变成响应式数据
                    const state = reactive(raw)	
            
                    function change() {
                        state.age = 90
                        console.log(state);
                    }
            
                    return {state, change}
                }
            }
            </script>

          ```
          
        - provide && inject
          
          ```html
            <script>
            import {provide} from 'vue'
            export default {
                setup() {
                    const obj= {
                        name: '前端印象',
                        age: 22
                    }
            
                    // 向子组件以及子孙组件传递名为info的数据
                    provide('info', obj)
                }
            }
            </script>
            
            // B.vue
            <script>
            import {inject} from 'vue'
            export default {
                setup() {	
                    // 接收A.vue传递过来的数据
                    inject('info')  // {name: '前端印象', age: 22}
                }
            }
            </script>
            
            // C.vue
            <script>
            import {inject} from 'vue'
            export default {
                setup() {	
                    // 接收A.vue传递过来的数据
                    inject('info')  // {name: '前端印象', age: 22}
                }
            }
            </script>
          ```  
          
        - watch   
            ```html
            <script>
                import {ref, watch} from 'vue'
                export default {
                setup() {
                const state = ref(0)
                
                        watch(state, (newValue, oldValue) => {
                            console.log(`原值为${oldValue}`)
                            console.log(`新值为${newValue}`)
                            /* 1秒后打印结果：
                                            原值为0
                                            新值为1
                            */
                        })
                
                        // 1秒后将state值+1
                        setTimeout(() => {
                            state.value ++
                        }, 1000)
                    }
                }
            </script>
            
            // 监听reactive类型
            <script>
                import {reactive, watch} from 'vue'
                export default {
                setup() {
                const state = reactive({count: 0})
                
                        watch(() => state.count, (newValue, oldValue) => {
                            console.log(`原值为${oldValue}`)
                            console.log(`新值为${newValue}`)
                            /* 1秒后打印结果：
                                            原值为0
                                            新值为1
                            */
                        })
                
                        // 1秒后将state.count的值+1
                        setTimeout(() => {
                            state.count ++
                        }, 1000)
                    }
                }
            </script>
            
            // 当同时监听多个值时
            <script>
                import {reactive, watch} from 'vue'
                export default {
                setup() {
                const state = reactive({ count: 0, name: 'zs' })
                
                        watch(
                            [() => state.count, () => state.name], 
                            ([newCount, newName], [oldvCount, oldvName]) => {
                                console.log(oldvCount) // 旧的 count 值
                                console.log(newCount) // 新的 count 值
                                console.log(oldName) // 旧的 name 值
                                console.log(newvName) // 新的 name 值
                            }
                        )
                
                        setTimeout(() => {
                          state.count ++
                          state.name = 'ls'
                        }, 1000)
                    }
                }
            </script>
            
            // watchEffect
            <script>
                import {reactive, watchEffect} from 'vue'
                export default {
                setup() {
                const state = reactive({ count: 0, name: 'zs' })
                
                        watchEffect(() => {
                            console.log(state.count)
                            console.log(state.name)
                            /*  初始化时打印：
                                            0
                                            zs
                
                                1秒后打印：
                                            1
                                            ls
                            */
                        })
                
                        setTimeout(() => {
                          state.count ++
                          state.name = 'ls'
                        }, 1000)
                    }
                }
            </script>
            ```
        - 获取标签元素
    
            ```html
               <template>
                  <div>
                    <div ref="el">div元素</div>
                  </div>
                </template>
                
                <script>
                import { ref, onMounted } from 'vue'
                export default {
                  setup() {
                      // 创建一个DOM引用，名称必须与元素的ref属性名相同
                      const el = ref(null)
                
                      // 在挂载后才能通过 el 获取到目标元素
                      onMounted(() => {
                        el.value.innerHTML = '内容被修改'
                      })
                
                      // 把创建的引用 return 出去
                      return {el}
                  }
                }
                </script>
            ```
        
        - vuex
    
            ```js
            // main.js
            import { createApp } from 'vue'
            import { createStore } from 'vuex'
            const store = createStore({
                state () {
                    return {
                        count: 0
                    }
                },
                mutations: {
                    increment (state) {
                        state.count++
                    }
                }
            })
            
            const app = createApp({ /* your root component */ })        
            app.use(store)
            
            // app.vue
            import { computed } from 'vue'
            import { useStore } from 'vuex'
            
            export default {
                setup () {
                    const store = useStore()
                    return {
                      // 在 computed 函数中访问一个 state
                      count: computed(() => store.state.count),
                
                      // 在 computed 函数中访问一个 getter
                      double: computed(() => store.getters.double)
                
                      // 访问一个 mutation
                      increment: () => store.commit('increment'),
                
                      // 访问一个 action
                      asyncIncrement: () => store.dispatch('asyncIncrement')
                    }
                }
            }
            ```
        - vueRouter

            ```js
            // 1. 定义路由组件.
            // 也可以从其他文件导入
            const Home = { template: '<div>Home</div>' }
            const About = { template: '<div>About</div>' }
            
            // 2. 定义一些路由
            // 每个路由都需要映射到一个组件。
            // 我们后面再讨论嵌套路由。
            const routes = [
            { path: '/', component: Home },
            { path: '/about', component: About },
            ]
            
            // 3. 创建路由实例并传递 `routes` 配置
            // 你可以在这里输入更多的配置，但我们在这里
            // 暂时保持简单
            const router = VueRouter.createRouter({
            // 4. 内部提供了 history 模式的实现。为了简单起见，我们在这里使用 hash 模式。
            history: VueRouter.createWebHashHistory(),
            routes, // `routes: routes` 的缩写
            })
            
            // 5. 创建并挂载根实例
            const app = Vue.createApp({})
            //确保 _use_ 路由实例使
            //整个应用支持路由。
            app.use(router)
            
            app.mount('#app')
            
            // 现在，应用已经启动了！
            
            // home.vue
            // Home.vue
            export default {
                computed: {
                    username() {
                        // 我们很快就会看到 `params` 是什么
                        return this.$route.params.username
                    },
                },
                methods: {
                    goToDashboard() {
                        if (isAuthenticated) {
                            this.$router.push('/dashboard')
                        } else {
                            this.$router.push('/login')
                        }
                    },
                },
            }
            ```

        - 案例
          
          ```html
            // 正常写法
            // app.vue
            <template>
                <div>
                    <div>{{count}}</div>
                    <button @click="plus">+</button>
                    <button @click="minus">-</button>
                </div>
            </template>
            <script lang="ts">
                import { defineComponent, ref, watch } from 'vue';
                
                export default defineComponent({
                    setup() {
                        const count = ref(0);
                        function plus() {
                            count.value += 1;
                        }
                        function minus() {
                            count.value -= 1;
                        }
                        watch(count, (newVal: number, oldVal: number) => {
                            console.log('newVal', newVal);
                            console.log('oldVal', oldVal);
                        });
                        return {
                            count,
                            plus,
                            minus,
                        };
                    },
                });
            </script>
          ```
          
            ```html
            // 自定义hook写法
            // app.vue
            <template>
            <div>
            <div>{{count}}</div>
            <button @click="plus">+</button>
            <button @click="minus">-</button>
            </div>
            </template>
            <script lang="ts">
                import { defineComponent } from 'vue';
                import { useCount } from './useCount.ts';
            
                export default defineComponent({
                    setup() {
                        const { minus, plus, count } = useCount(10);
                        return {
                            count,
                            plus,
                            minus,
                        };
                    },
                });
            </script>
            ```
          
          ```ts
            // 自定义hook写法
            // useCount.ts
            import { ref, Ref, watch } from 'vue';

            interface Result {
                count: Ref<number>;
                minus: (num: number) => void;
                plus: (num: number) => void;
            }
            
            export function useCount(init: number = 0): Result {
                const count = ref(init);
                
                const minus = (num: number) => {
                    count.value -= 1;
                };
                const plus = (num: number) => {
                    count.value += 1;
                };
                watch(count, (newVal: number, oldVal: number) => {
                    console.log('newVal', newVal);
                    console.log('oldVal', oldVal);
                });
                
                return {
                    count, minus, plus,
                };
            }

          ```

        - 与react hook对比
          
            ```js
            // app.js
            import React from 'react';
            import useCounter from './useCounter';
            
            function CounterOne() {
                const { count, increment, decrement } = useCounter(10);
                return (
                    <div>
                    <h2>Count - {count}</h2>
                    <button onClick={increment}>increment</button>
                    <button onClick={decrement}>decrement</button>
                    </div>
                );
            }
            
            export default CounterOne;
            
            // useCounter.js
            import { useState } from 'react';
        
            function useCounter(num = 10) {
                const [count, setCount] = useState(num);
                const increment = () => {
                    setCount((prevCount) => prevCount + 1);
                };
                const decrement = () => {
                    setCount((prevCount) => prevCount - 1);
                };
                return {
                    count, increment, decrement,
                };
            }
            
            export default useCounter;
    
            ```
