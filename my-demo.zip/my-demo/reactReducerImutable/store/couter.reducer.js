import { fromJS } from 'immutable';
import { INCREMENT, DRCREMENT } from './constants.js';

const defaultState = fromJS({
  count: 0,
});
const counter = (state = defaultState, action) => {
  const oState = state.toJS();
  switch (action.type) {
    case INCREMENT:
      oState.count += 1;
      return state.merge(oState);
    case DRCREMENT:
      oState.count -= 1;
      return state.merge(oState);
    default:
      return state;
  }
};

export default counter;
