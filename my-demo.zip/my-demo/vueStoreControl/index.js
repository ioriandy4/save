import Vue from 'vue';

import VueRouter from 'vue-router';
import app from './app.vue';

import { routeConfig } from './router/router';
import { store } from './store/index';

Vue.use(VueRouter);

const router = new VueRouter({
  routes: routeConfig,
});

const debug = process.env.NODE_ENV !== 'production';

console.log('process.env.NODE_ENV', process.env.NODE_ENV);

Vue.config.productionTip = debug;

window.a = new Vue({
  el: '#app',
  store,
  router,
  render: (h) => h(app),
});
