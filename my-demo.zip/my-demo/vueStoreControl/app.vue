<template>
    <div>
        <hr>
        <p>vuex</p>
        <p>count1的count {{count}}</p>
        <p>count2的count {{count2}}</p>
        <button @click="this.addCount">+1</button>
        <button @click="this.minusCount">-1</button>
        <button @click="this.addCount2">+1</button>
        <button @click="this.minusCount2">-1</button>
        <hr>
        <p>component</p>
        <child :txt.sync="msg"></child>
        <hr>
        <p>router</p>
        <p>
            <router-link to="/foo">Go to Foo</router-link>
            <router-link to="/bar">Go to Bar</router-link>
        </p>
        <router-view></router-view>
        <hr>
        <p>store controll</p>
        <button @click="getStore">get store1</button>
        <button @click="setStore">set store1</button>
        <button @click="getStore2">get store2</button>
        <button @click="setStore2">set store2</button>
    </div>
</template>
<script>
import { mapState, mapActions } from 'vuex';
import child from './child.vue';
import { storeControl } from './store/storeController';

export default {
  data() {
    return {
      msg: 1111,
    };
  },
  components: {
    child,
  },
  methods: {
    ...mapActions('count2', [
      'addCount',
      'minusCount',
    ]),
    ...mapActions('count', {
      addCount2: 'addCount',
      minusCount2: 'minusCount',
    }),
    getStore() {
      console.log(storeControl.getStore('count').count);
    },
    setStore() {
      storeControl.setStore('count/add', 100);
    },
    getStore2() {
      console.log(storeControl.getStore('count2').count);
    },
    setStore2() {
      storeControl.setStore('count2/add', 100);
    },
    handleChange3() {
      if (this.c > 10) {
        return;
      }
      this.$nextTick(() => {
        // eslint-disable-next-line no-debugger
        this.c += 1;
        this.handleChange3();
      });
    },
    create() {
      const a = {
        a: 'aaa',
      };
      // a.b();
      console.log(a);
    },
  },
  computed: {
    ...mapState({
      count: (state) => state.count.count,
      count2: (state) => state.count2.count,
    }),
  },
};
</script>
