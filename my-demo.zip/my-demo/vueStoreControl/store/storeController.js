import { store } from './index';

class StoreController {
  getStore(storeName) {
    return store.state[storeName];
  }

  setStore(commitName, val) {
    store.commit(commitName, val);
  }
}

const storeControl = new StoreController();
export {
  storeControl,
};
