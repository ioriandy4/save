const state = {
  count: 0,
};

const actions = {
  // addCount({ commit, state }, params = {}) {
  addCount({ commit, state }) {
    commit('add', state.count + 1);
  },
  minusCount({ commit, state }) {
    commit('add', state.count - 1);
  },
};
const mutations = {
  add(state, payload) {
    state.count = payload;
  },
};
export default {
  namespaced: true,
  state,
  mutations,
  actions,
};
