const state = {
  count: 88,
};

const actions = {
  // addCount({ commit, state }, params = {}) {
  addCount({ commit, state }) {
    commit('add', state.count + 10);
  },
  minusCount({ commit, state }) {
    commit('add', state.count - 10);
  },
};
const mutations = {
  add(state, payload) {
    state.count = payload;
  },
};
export default {
  namespaced: true,
  state,
  mutations,
  actions,
};
