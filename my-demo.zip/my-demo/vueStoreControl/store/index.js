import Vuex from 'vuex';
import Vue from 'vue';
import count from './store';
import count2 from './store2';

Vue.use(Vuex);
const store = new Vuex.Store({
  modules: {
    count,
    count2,
  },
});

export {
  store,
};
