import {configureStore} from '@reduxjs/toolkit'
import a from './slice/a.slice.ts'
import b from './slice/b.slice.ts'
const store = configureStore({
    reducer:{
        dataA:a,
        dataB:b
    },
    middleware:getDefaultMiddleware => getDefaultMiddleware({
        serializableCheck:false
    })
    // middleware: ...
})

export default store