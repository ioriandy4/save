import { createSlice } from "@reduxjs/toolkit";

const initialState = [];

// 固定格式，创建 slice 对象
const todoSlice = createSlice({
    name: 'todo',
    initialState,
    // 相当于原来reducer中的case
    reducers: {
        // 后面文中我们将这类函数称之为 case
        addTodo: (state, action) => {
            state.push(action.payload);
        },
        delTodo: (state, action) => {
            // 这里要注意不能使用之前的filter方式，因为immer的原因，我们必须直接操作state
            const index = state.findIndex(item => item.id === action.payload);
            state.splice(index, 1);
        }
    }
});

// 官方推荐使用 ES6 解构和导出语法
// 提取action creator 对象与reducer函数
const { reducer, actions } = todoSlice;
// 提取并导出根据reducers命名的 action creator 函数
export const { addTodo, delTodo } = actions;
// 导出 reducer 函数
export default reducer;