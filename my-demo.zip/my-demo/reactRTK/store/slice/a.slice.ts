import {createSlice,createAsyncThunk} from "@reduxjs/toolkit"


const orderSlice = createSlice({
    name:"order", // type: order/set,,,
    initialState:{
        a: 0,
        b: 0
    },
    reducers:{
        plusA(state,action){
            console.log(action)
            state.a = state.a + action.payload
        },
        minusA(state,action){
            console.log('/???')
            state.a = state.a - 1
        },
        plusB(state,action){
            state.b = state.b + 1
        }
    }
})
export default orderSlice.reducer;
export const {plusA,minusA} = orderSlice.actions
export const asyncMethodA = createAsyncThunk(
    "order/plusA",
    async (data, {dispatch}) =>{
        setTimeout(() => {
            dispatch(plusA(100))
        }, 1000);
    }
)
