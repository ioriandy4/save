import './App.css';
import {useDispatch, useSelector} from 'react-redux';
import { asyncMethodA, minusA } from './store/slice/a.slice.ts';



function App() {
  const a = useSelector(state => state.dataA)
  const dispatch = useDispatch()
  const plus = () => {
    dispatch(asyncMethodA(10000))
  }
  const minus = () => {
    console.log('clickmin')
    console.log(minusA)
    dispatch(minusA(2222))
  }
  return (
      <div className="App">
        <h3>{a.a}</h3>
        <button onClick={plus}>++</button>
        <button onClick={minus}>--</button>
      </div>
  );
}

export default App;
