import React, { Component } from 'react';
import { observer, inject } from 'mobx-react';

@inject('mobx')
@inject('mobx2')
@observer
class MobxTest extends Component {
  render() {
    return (
          <div>
            {this.props.mobx.num}
            {this.props.mobx2.num}
            <button onClick={() => this.props.mobx.decrement()}>-1</button>
            <button onClick={() => this.props.mobx.increment()}>+1</button>
          </div>
    );
  }
}

export default MobxTest;
