import { observable, action } from 'mobx';
// 常量改成类
class AppState {
  @observable num = 0;

  @action
  increment() {
    this.num += 1;
  }

  @action
  decrement() {
    this.num -= 1;
  }
}
const appState = new AppState();

export default appState;
