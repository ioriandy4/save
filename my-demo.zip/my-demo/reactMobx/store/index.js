import mobx from './mobx';
import mobx2 from './mobx2';

const stores = {
  mobx,
  mobx2,
};
export default stores;
