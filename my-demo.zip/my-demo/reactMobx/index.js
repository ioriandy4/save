import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'mobx-react';
import MobxTest from './App';

import stores from './store/index';

ReactDOM.render((
      <Provider {...stores}>
        <MobxTest />
      </Provider>
), document.querySelector('#app'));
