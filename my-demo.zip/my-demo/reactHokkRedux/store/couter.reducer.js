const init = {
  num: 1,
};
export default function (state = init, action) {
  switch (action.type) {
    case 'increase':
      console.log(123);
      return { num: 11111 };
    default:
      return state;
  }
}
