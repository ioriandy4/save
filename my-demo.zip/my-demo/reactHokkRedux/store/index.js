import { createStore } from 'redux';
import reducer from './couter.reducer';

export default createStore(reducer);
