const Foo = () => import('../components/foo.vue');
const Bar = () => import('../components/bar.vue');

const routeConfig = [
  { path: '/foo', component: Foo },
  { path: '/bar', component: Bar },
];

export {
  routeConfig,
};
