import Vue from 'vue';
import Vuex from 'vuex';
import VueRouter from 'vue-router';
import app from './app.vue';
import count from './store/store';
import { routeConfig } from './router/router';

Vue.use(VueRouter);

const router = new VueRouter({
  routes: routeConfig,
});

const debug = process.env.NODE_ENV !== 'production';
Vue.use(Vuex);
const store = new Vuex.Store({
  modules: {
    count,
  },
});

console.log('process.env.NODE_ENV', process.env.NODE_ENV);

Vue.config.productionTip = debug;
// window.__store = store;

window.a = new Vue({
  el: '#app',
  store,
  router,
  render: (h) => h(app),
});
