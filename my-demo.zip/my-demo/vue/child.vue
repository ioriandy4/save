<template>
    <div>
        {{txt}}
        <button @click="send">修改</button>
        <p>{{txt}}</p>
    </div>
</template>
<script>
export default {
  props: {
    txt: {
      type: Number,
    },
  },
  data() {
    const obj = {
      a: 'aaa',
    };
    return {
      ...obj,
    };
  },
  methods: {
    send() {
      this.$emit('update:txt', 678);
    },
  },
};
</script>
