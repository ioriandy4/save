<template>
    <div>
        <hr>
        <p>vuex</p>
        {{count.count}}
        <button @click="this.addCount"> +1</button>
        <button @click="this.minusCount">-1</button>
        <hr>
        <p>component</p>
        <child :txt.sync="msg"></child>
        <hr>
        <p>router</p>
        <p>
            <router-link to="/foo">Go to Foo</router-link>
            <router-link to="/bar">Go to Bar</router-link>
        </p>
        <router-view></router-view>
    </div>
</template>
<script>
import { mapState, mapActions } from 'vuex';
import child from './child.vue';

export default {
  data() {
    return {
      msg: 1111,
    };
  },
  components: {
    child,
  },
  methods: {
    ...mapActions([
      'addCount',
      'minusCount',
    ]),
    handleChange3() {
      if (this.c > 10) {
        return;
      }
      this.$nextTick(() => {
        // eslint-disable-next-line no-debugger
        this.c += 1;
        this.handleChange3();
      });
    },
    create() {
      const a = {
        a: 'aaa',
      };
      // a.b();
      console.log(a);
    },
  },
  computed: { ...mapState(['count']) },
};
</script>
