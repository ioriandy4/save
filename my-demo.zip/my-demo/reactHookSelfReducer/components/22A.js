import React, { useContext } from 'react';
import { CountContext } from '../store/index.js';

function A() {
  const countContext = useContext(CountContext);
  console.log('countContext', countContext);
  return (
        <div>
            A - {countContext.reducer2.state.firstCounter2}
            <button
                onClick={() => countContext.reducer2.dispatch('increment2')}
            >Increment</button>
            <button
                onClick={() => countContext.reducer2.dispatch('decrement2')}
            >Decrement</button>
            <button
                onClick={() => countContext.reducer2.dispatch('reset2')}
            >Reset</button>
        </div>
  );
}

export default A;
