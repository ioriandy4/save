import React from 'react';
import {
  CountContext, reducer1, reducer2, initialState, initialState2,
} from '../store/index';
import A from './22A.js';
import useCombineReducer from '../hook/useCombineReducer.js';

const App = () => {
  // 初始写法
  // const [state, dispatch] = useReducer(reducer1, initialState);
  // const [state2, dispatch2] = useReducer(reducer2, initialState2);
  // const combineReducer = {
  //   reducer1: {
  //     state,
  //     dispatch,
  //   },
  //   reducer2: {
  //     state: state2,
  //     dispatch: dispatch2,
  //   },
  // };

  // 封装成hook
  const combineReducer = useCombineReducer([{
    name: 'reducer1',
    reducer: reducer1,
    initialState,
  }, {
    name: 'reducer2',
    reducer: reducer2,
    initialState: initialState2,
  }]);
  return (
        <CountContext.Provider
            value={combineReducer}
        >
            <div className="App">
                Count - {combineReducer.reducer2.state.firstCounter}
                <A />
            </div>
        </CountContext.Provider>
  );
};

export default App;
