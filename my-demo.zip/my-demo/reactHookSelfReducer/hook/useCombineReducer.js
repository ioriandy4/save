import { useReducer } from 'react';

function useCombineReducer(data) {
  const combineReducer = {};
  data.forEach((val, index) => {
    let nameState = `state${index}`;
    let nameDispatch = `dispatch${index}`;
    const nameKey = val.name;
    [nameState, nameDispatch] = useReducer(data[index].reducer, data[index].initialState);
    combineReducer[nameKey] = {
      state: nameState,
      dispatch: nameDispatch,
    };
  });
  return combineReducer;
}

export default useCombineReducer;
