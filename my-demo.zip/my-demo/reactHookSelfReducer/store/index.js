import React from 'react';

const CountContext = React.createContext({});

const initialState = {
  firstCounter: 10,
};

const reducer1 = (state = initialState, action) => {
  switch (action) {
    case 'increment':
      return {
        firstCounter: state.firstCounter + 1,
      };
    case 'decrement':
      return {
        firstCounter: state.firstCounter - 1,
      };
    case 'reset':
      return initialState;
    default:
      return state;
  }
};

const initialState2 = {
  firstCounter: 2,
};
const reducer2 = (state = initialState2, action) => {
  switch (action) {
    case 'increment2':
      return {
        firstCounter: state.firstCounter + 1,
      };
    case 'decrement2':
      return {
        firstCounter: state.firstCounter - 1,
      };
    case 'reset2':
      return initialState2;
    default:
      return state;
  }
};

export {
  reducer1,
  reducer2,
  CountContext,
  initialState,
  initialState2,
};
