import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.js';
import myTimer from './store/index.js';

ReactDOM.render(
    <App timer={myTimer}/>,
    document.getElementById('app'),
);
