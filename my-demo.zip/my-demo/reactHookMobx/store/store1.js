import { makeAutoObservable } from 'mobx';

class Store {
  secondsPassed = 0

  constructor() {
    makeAutoObservable(this);
  }

  increaseTimer() {
    console.log('this', this);
    this.secondsPassed += 1;
  }

  minTimer() {
    this.secondsPassed -= 1;
  }
}

export default new Store();
