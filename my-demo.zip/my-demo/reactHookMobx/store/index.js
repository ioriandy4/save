import store1 from './store1';
import store2 from './store2';

const store = {
  store1,
  store2,
};

export default store;
