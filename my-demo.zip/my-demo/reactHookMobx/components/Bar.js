import React from 'react';

const Bar = () => (
  <div>
    <p> i am bar</p>
  </div>
);

export default Bar;
