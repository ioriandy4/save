import React from 'react';

const Child = (props = {}) => (
    <div>
      <p>i am child data : {props.number}</p>
      <button onClick={() => { props.changeChild(100); }}>change child number</button>
    </div>
);

export default Child;
