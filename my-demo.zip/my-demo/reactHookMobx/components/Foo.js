import React from 'react';

const Foo = () => (
    <div>
      <p> i am foo</p>
    </div>
);

export default Foo;
