import React, { useState } from 'react';
import { Route, Link, HashRouter } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import Child from './Child';
import Foo from './Foo';
import Bar from './Bar';

const App = observer((props) => {
  const [number, setNumber] = useState(0);
  const addClick = () => {
    setNumber(number + 1);
  };
  const minClick = () => {
    setNumber(number - 1);
  };
  const changeChild = (data) => {
    setNumber(data);
  };
  const addStore = () => {
    props.timer.store1.increaseTimer();
  };

  const minStore = () => {
    props.timer.store1.minTimer();
  };
  return (
    <div>
      <div>{number}</div>
      <div><button onClick={addClick}>add</button></div>
      <div><button onClick={minClick}>min</button></div>
      <hr/>
      <div><Child number={number} changeChild={changeChild} /></div>
      <hr/>
      <div>router</div>
      <HashRouter>
        <Link to='/'>index</Link>
        <Link to='/foo'>foo</Link>
        <Link to='/bar'>bar</Link>
        <Route path='/' exact component={Foo} />
        <Route path='/foo' exact component={Foo} />
        <Route path='/bar' exact component={Bar} />
      </HashRouter>
      <hr/>
      <div>test store</div>
      <h1>{props.timer.store1.secondsPassed}</h1>
      <div><button onClick={addStore}>add</button></div>
      <div><button onClick={minStore}>min</button></div>
    </div>
  );
});

export default App;
