import React from 'react';
import ReactDOM from 'react-dom';

import { observer } from 'mobx-react-lite';
import myTimer from './store/index.js';

const TimerView = observer(({ timer }) => <span>
  Seconds passed: {timer.store1.secondsPassed}</span>);

ReactDOM.render(
  <TimerView timer={myTimer} />,
  document.getElementById('app'),
);

setInterval(() => {
  myTimer.store1.increaseTimer();
}, 1000);
