// import React, { Component } from "react";
// import { connect } from "react-redux";
import { actionName } from "./store";
//
// const mapStateToProps = (state) => ({
//   num: state.counter.count,
// });
// const asyncAdd = () => (dispatch) => {
//   setTimeout(() => {
//     dispatch({ type: actionName.INCREMENT });
//   }, 1000);
// };
// const mapDispatchToProps = (dispatch) => ({
//   increment: () => {
//     dispatch({ type: actionName.INCREMENT });
//   },
//   decrement: () => {
//     dispatch({
//       type: actionName.DRCREMENT,
//     });
//   },
//   asyncIncrement: () => {
//     dispatch(asyncAdd());
//   },
// });
//
// @connect(mapStateToProps, mapDispatchToProps)
// class ReduxTest extends Component {
//   // shouldComponentUpdate(nextProps, nextState, nextContext) {
//   //   debugger;
//   //   return true;
//   // }
//
//   render() {
//     return (
//       <div>
//         <p>{this.props.num}</p>
//         <button onClick={() => this.props.decrement()}>-1</button>
//         <button onClick={() => this.props.increment()}>+1</button>
//         <button onClick={() => this.props.asyncIncrement()}>async+1</button>
//       </div>
//     );
//   }
// }
//
// export default ReduxTest;

import React from "react";
import { useSelector, useDispatch } from "react-redux";

function ReduxTest(props) {
  console.log(props);
  const num = useSelector((state) => state);
  const dispatch = useDispatch();
  const increase = () => {
    dispatch({ type: actionName.INCREMENT });
  };
  const decrease = () => {
    dispatch({ type: actionName.DRCREMENT });
  };
  const asyncIncrease = () => {
    setTimeout(() => {
      dispatch({ type: actionName.INCREMENT });
    }, 2000);
  };
  return (
    <div>
      <p>{num.counter2.count}???</p>
      <button onClick={increase}>-1</button>
      <button onClick={decrease}>+1</button>
      <button onClick={asyncIncrease}>async+1</button>
    </div>
  );
}

export default ReduxTest;
