<template>
    <div>
        <button @click="send">修改</button>
        <p>{{txt}}</p>
    </div>
</template>
<script lang='ts'>
import Component from 'vue-class-component';
import Vue from 'vue';
import { Prop } from 'vue-property-decorator';

@Component({
  components: {
  },
})
export default class app extends Vue {
  @Prop({
    type: Number,
    default() {
      return {};
    },
  })
  private txt!: Number;

  send() {
    this.$emit('textChange', 678);
  }
}
</script>
