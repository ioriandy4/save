import Vue from 'vue';
import Vuex from 'vuex';
import VueRouter from 'vue-router';
import app from './app.vue';
import count from './store/store';
import { routeConfig } from './router/router';

const debug = process.env.NODE_ENV !== 'production';

Vue.use(VueRouter);
const router = new VueRouter({
  routes: routeConfig,
});

Vue.use(Vuex);
const store = new Vuex.Store({
  modules: {
    count,
  },
});

console.log('process.env.NODE_ENV', process.env.NODE_ENV);

Vue.config.productionTip = debug;

(window as any).__store = store;

(window as any).a = new Vue({
  el: '#app',
  store,
  router,
  render: (h) => h(app),
});
