<template>
    <div>
        {{count.count}}
        <button @click="this.addCount">++1</button>
        <button @click="this.minusCount">--1</button>
        <hr>
        <child $ref="xx" :txt="msg" @textChange = textChange></child>
        <hr>
        <p>router</p>
        <p>
            <router-link to="/foo">Go to Foo</router-link>
            <router-link to="/bar">Go to Bar</router-link>
        </p>
        <router-view></router-view>
    </div>
</template>
<script lang='ts'>
import Component from 'vue-class-component';
import { State, Action } from 'vuex-class';
import Vue from 'vue';
import child from './child.vue';

@Component({
  components: {
    child,
  },
})
export default class app extends Vue {
  private msg: number = 1111;

  @State('count') private count;

  @Action('addCount') private addCount;

  @Action('minusCount') private minusCount;

  textChange(txt) {
    console.log(txt);
    this.msg = txt;
    const a = this.$refs.xx as string;
    a.charAt(1);
  }
}
</script>
