import React from "react";
import { useLocation, useSearchParams } from "react-router-dom";
import querySrring from "query-string";
const Home = () => {
  const useLocationObj = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();
  const handleClick = () => {
    console.log(useLocationObj);
    console.log(useLocationObj.search);
    console.log(querySrring.parse(useLocationObj.search));
    console.log(searchParams);
    console.log(searchParams.toString());
    console.log(searchParams.get("a"));
    console.log(searchParams.getAll("a"));
  };
  const handleChangeParams = () => {
    setSearchParams({ c: "ccc", d: "cc" });
  };
  return (
    <div>
      <h1 onClick={handleClick}>Aaa</h1>
      <button onClick={handleChangeParams}>handleChangeParams</button>
    </div>
  );
};

export default Home;
