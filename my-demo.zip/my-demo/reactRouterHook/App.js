// import React, { Component } from "react";
// import { connect } from "react-redux";
import { actionName } from "./store";
import { Link, Routes, Route, useNavigate } from "react-router-dom";
import Aaa from "./Aaa";
import Bbb from "./Bbb";
import querySrring from "query-string";
//
// const mapStateToProps = (state) => ({
//   num: state.counter.count,
// });
// const asyncAdd = () => (dispatch) => {
//   setTimeout(() => {
//     dispatch({ type: actionName.INCREMENT });
//   }, 1000);
// };
// const mapDispatchToProps = (dispatch) => ({
//   increment: () => {
//     dispatch({ type: actionName.INCREMENT });
//   },
//   decrement: () => {
//     dispatch({
//       type: actionName.DRCREMENT,
//     });
//   },
//   asyncIncrement: () => {
//     dispatch(asyncAdd());
//   },
// });
//
// @connect(mapStateToProps, mapDispatchToProps)
// class ReduxTest extends Component {
//   // shouldComponentUpdate(nextProps, nextState, nextContext) {
//   //   debugger;
//   //   return true;
//   // }
//
//   render() {
//     return (
//       <div>
//         <p>{this.props.num}</p>
//         <button onClick={() => this.props.decrement()}>-1</button>
//         <button onClick={() => this.props.increment()}>+1</button>
//         <button onClick={() => this.props.asyncIncrement()}>async+1</button>
//       </div>
//     );
//   }
// }
//
// export default ReduxTest;

import React from "react";
import { useSelector, useDispatch } from "react-redux";

function ReduxTest(props) {
  console.log(querySrring);
  console.log(querySrring.stringify({ a: "aaa", b: "bbb" }));
  const navigate = useNavigate();
  const num = useSelector((state) => state);
  const dispatch = useDispatch();
  const increase = () => {
    dispatch({ type: actionName.INCREMENT });
  };
  const decrease = () => {
    dispatch({ type: actionName.DRCREMENT });
  };
  const asyncIncrease = () => {
    setTimeout(() => {
      dispatch({ type: actionName.INCREMENT });
    }, 2000);
  };
  const linetoHome = () => {
    // 第一种，非url search方式
    // navigate("/home", { state: { name: "kaiqin" }, query: { a: "aaa" } });
    navigate(`/home?${querySrring.stringify({ a: "aaa", b: "bbb" })}`);
  };
  const linetoAbout = () => {
    navigate("/about", { state: { name: "kaiqin" } });
  };

  return (
    <div>
      <Link to="/home">home</Link> | <Link to="/about">about</Link>
      <button onClick={linetoAbout}>linetoAbout</button>
      <button onClick={linetoHome}>linetoHome</button>
      <Routes>
        <Route path="/" element={<Aaa />} />
        <Route path="/home" element={<Aaa />} />
        <Route path="/about" element={<Bbb />} />
      </Routes>
      <h1>111</h1>
      <p>{num.counter2.count}???</p>
      <button onClick={increase}>-1</button>
      <button onClick={decrease}>+1</button>
      <button onClick={asyncIncrease}>async+1</button>
    </div>
  );
}

export default ReduxTest;
