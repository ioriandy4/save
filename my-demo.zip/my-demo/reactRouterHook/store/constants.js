export const INCREMENT = "INCREMENT";
export const INCREMENT2 = "INCREMENT2";
export const DRCREMENT = "DRCREMENT";
const constants = {
  INCREMENT,
  DRCREMENT,
  INCREMENT2,
};
export default constants;
