import produce from "immer";
import { DRCREMENT, INCREMENT } from "./constants.js";

const defaultState = {
  count: 0,
};

// const counter = (state = defaultState, action) => produce(state, (draft) => {
//   debugger;
//   switch (action.type) {
//     case INCREMENT:
//       draft.count += 1;
//       break;
//     case DRCREMENT:
//       draft.count -= 1;
//       break;
//     default:
//   }
// });

function createReducer(cases) {
  return (state = defaultState, action) =>
    produce(state, (draft) => {
      // 返回一份新的state
      if (action && action.type && cases[action.type] instanceof Function) {
        cases[action.type](draft, action);
      }
    });
}

const counter = createReducer({
  [INCREMENT](state) {
    state.count += 10;
  },
  [DRCREMENT](state) {
    state.count -= 1;
  },
});

export default counter;
