// eslint-disable-next-line no-unused-vars
import { call, put, take, fork, takeEvery } from "redux-saga/effects";
import { actionName } from "./index";
// import { fetchUserInfoAPI } from "./api";

const fetchUserInfoAPI = () => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(100);
    }, 100);
  });
};

function* fetchUserInfo() {
  while (true) {
    yield take("saga1");
    try {
      const user = yield call(fetchUserInfoAPI);
      yield put({ type: actionName.INCREMENT, payload: user });
    } catch (e) {
      // console.log(e);
      // yield put({ type: actionName.DRCREMENT, payload: e.message });
    }
  }
}

function* fetchUserInfo2() {
  while (true) {
    yield take("saga2");
    try {
      const user = yield call(fetchUserInfoAPI);
      yield put({ type: actionName.DRCREMENT, payload: user });
    } catch (e) {
      // console.log(e);
      // yield put({ type: actionName.DRCREMENT, payload: e.message });
    }
  }
}

function* rootSaga() {
  // yield takeEvery("saga1", fetchUserInfo);
  // while (true) {
  //   yield take("saga1");
  //   yield fork(fetchUserInfo);
  //   yield take("saga2");
  //   yield fork(fetchUserInfo2);
  // }
  yield fork(fetchUserInfo);
  yield fork(fetchUserInfo2);
}

export default rootSaga;
