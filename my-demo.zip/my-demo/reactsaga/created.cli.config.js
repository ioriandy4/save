const path = require("path");

const ROOT_PATH = process.cwd();
const config = {
  extractCss: true,
  temPath: path.resolve(process.cwd(), "src/temPath"),
  global: {
    ENV: "ENV",
    EEE: "EEE",
  },
  beforeBuild: (callBack) => {
    console.log("before");
    callBack();
  },
  afterBuild: () => {
    console.log("after");
  },
  entry: [
    {
      src: path.resolve(ROOT_PATH, "./reactReducer/index.js"),
      html: path.resolve(ROOT_PATH, "./reactReducer/index.html"),
    },
  ],
  serverConfig: {
    port: 9001,
    hot: true,
    writeToDisk: false,
  },
  combine: {
    output: {
      path: path.resolve(ROOT_PATH, "dist"),
      filename: "assets/js/[name].[contenthash:5].js",
      libraryTarget: "umd",
    },
  },
};

module.exports = {
  config,
};
