import React, { Component } from 'react';
import { connect } from 'react-redux';
import { actionName } from './store';

const mapStateToProps = (state) => ({
  num: state.counter,
});
const asyncAdd = () => (dispatch) => {
  setTimeout(() => {
    dispatch({ type: actionName.INCREMENT });
  }, 1000);
};
const mapDispatchToProps = (dispatch) => ({
  increment: () => {
    dispatch({ type: actionName.INCREMENT });
  },
  decrement: () => {
    dispatch({
      type: actionName.DRCREMENT,
    });
  },
  asyncIncrement: () => {
    dispatch(asyncAdd());
  },

});

@connect(mapStateToProps, mapDispatchToProps)
class ReduxTest extends Component {
  render() {
    return (
      <div>
        <p>{this.props.num}</p>
        <button onClick={() => this.props.decrement()}>-1</button>
        <button onClick={() => this.props.increment()}>+1</button>
        <button onClick={() => this.props.asyncIncrement()}>async+1</button>
      </div>
    );
  }
}

export default ReduxTest;
