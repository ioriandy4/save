export const INCREMENT = 'INCREMENT';
export const DRCREMENT = 'DRCREMENT';
const constants = {
  INCREMENT,
  DRCREMENT,
};
export default constants;
