import { INCREMENT, DRCREMENT } from './constants.js';

const counter = (state = 0, action) => {
  switch (action.type) {
    case INCREMENT:
      return state + 1;
    case DRCREMENT:
      return state - 1;
    default:
      return state;
  }
};

export default counter;
