import React, { Component } from "react";
class Home extends Component {
  handleClick = () => {
    console.log(this.props);
    console.log(this.props.location.search);
    this.props.history.push("/home?c=ccc&d=ddd");
  };

  render() {
    return (
      <div>
        <h1 onClick={this.handleClick}>Bbb</h1>
      </div>
    );
  }
}

export default Home;
