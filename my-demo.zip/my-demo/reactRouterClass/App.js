/* eslint-disable */
import React, { Component } from "react";
import { connect } from "react-redux";
import { actionName } from "./store";
import { HashRouter, Route, Link } from 'react-router-dom'
import Home from "./Home";
import Aaa from "./Aaa";
import Bbb from "./Bbb";

const mapStateToProps = (state) => ({
  num: state.counter.count,
});
const asyncAdd = () => (dispatch) => {
  setTimeout(() => {
    dispatch({ type: actionName.INCREMENT });
  }, 1000);
};
const mapDispatchToProps = (dispatch) => ({
  increment: () => {
    dispatch({ type: actionName.INCREMENT });
  },
  decrement: () => {
    dispatch({
      type: actionName.DRCREMENT,
    });
  },
  asyncIncrement: () => {
    dispatch(asyncAdd());
  },
});

@connect(mapStateToProps, mapDispatchToProps)
class ReduxTest extends Component {
  toIndex = () => {
    console.log('外层无数据')
  }
  toAbout = () => {
    console.log('外层无数据')
  }
  getRoutes = () => {
    const router1 = [
      {
        path: '/',
        component: Aaa
      },
      {
        path: '/home',
        component: Aaa
      },
      {
        path: '/about',
        component: Bbb
      }
    ]
    return(
      <div>
        {router1.map((val) => {
          return <Route key={val.path} path={val.path} exact component={val.component}></Route>
        })}
        {/* <Route path='/' exact component={Aaa}></Route> */}
        {/* <Route path='/home' exact component={Aaa}></Route> */}
        {/* <Route path='/about' exact component={Bbb}></Route> */}
      </div>
    )
  }
  render() {
    return (
      <div>
          <button onClick={this.toIndex}>首页点击</button>
          <button onClick={this.toAbout}>关于</button>
          <div>
            <HashRouter>
              <Link to="/home">首页</Link>
              <Link to="/about">关于</Link>
              <div>
                {this.getRoutes()}
              </div>
            </HashRouter>
          </div>
        <h1>111</h1>
        <p>{this.props.num}</p>
        <button onClick={() => this.props.decrement()}>-1</button>
        <button onClick={() => this.props.increment()}>+1</button>
        <button onClick={() => this.props.asyncIncrement()}>async+1</button>
      </div>
    );
  }
}

export default ReduxTest;
