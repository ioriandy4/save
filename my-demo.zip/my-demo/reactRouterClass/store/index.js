import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from "redux-thunk";
import counter from "./couter.reducer";
import actionName from "./constants.js";

const store = createStore(
  combineReducers({
    counter,
  }),
  applyMiddleware(thunk)
);
export { store, actionName };

// export default store;
