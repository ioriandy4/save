import React, { Component } from "react";
import AaaChild from "./AaaChild";
class Home extends Component {
  handleClick = () => {
    console.log(this.props);
    console.log(this.props.location.search);
    // this.props.history.push("/about?a=aaa&b=bbb");
    // this.props.history.replace("/about")
    this.props.history.push({
      pathname: "/about",
      search: "a=1",
    });
  };

  render() {
    return (
      <div>
        <h1 onClick={this.handleClick}>Aaa</h1>
        <AaaChild />
      </div>
    );
  }
}

export default Home;
