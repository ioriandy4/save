// eslint-disable-next-line import/no-extraneous-dependencies
const micromatch = require('micromatch');
const path = require('path');
// eslint-disable-next-line import/no-extraneous-dependencies
const rl = require('readlines');

const lines = rl.readlinesSync(path.resolve(process.cwd(), './.eslintignore'));
const lineArr = lines.map((val) => {
  if (val !== '') {
    return `${process.cwd()}/${val}`;
  }
  return null;
});

module.exports = {
  '*.{vue,js,jsx,ts,tsx}': (files) => {
    if (lineArr.length === 0) {
      return `eslint ${files.join(' ')}`;
    }
    const match = micromatch.not(files, lineArr, {});
    return `eslint ${match.join(' ')}`;
  },
};
