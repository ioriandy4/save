import React, { Component } from "react";
import { connect } from "react-redux";
import { actionName } from "./store";
import propType from "prop-types";

const mapStateToProps = (state) => ({
  num: state.counter,
});
const asyncAdd = () => (dispatch) => {
  setTimeout(() => {
    dispatch({ type: actionName.INCREMENT });
  }, 100);
};
const mapDispatchToProps = (dispatch) => ({
  increment: () => {
    dispatch({ type: "saga1" });
  },
  decrement: () => {
    dispatch({
      type: "saga2",
    });
  },
  asyncIncrement: () => {
    dispatch(asyncAdd());
  },
});

@connect(mapStateToProps, mapDispatchToProps)
class ReduxTest extends Component {
  render() {
    return (
      <div>
        <p>{this.props.num}</p>
        <button onClick={() => this.props.decrement()}>-1</button>
        <button onClick={() => this.props.increment()}>+1</button>
        <button onClick={() => this.props.asyncIncrement()}>async+1</button>
      </div>
    );
  }
}
ReduxTest.propTypes = {
  num: propType.number,
  decrement: propType.func,
  increment: propType.func,
  asyncIncrement: propType.func,
};

export default ReduxTest;
