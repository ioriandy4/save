module.exports = {
  presets: [
    ['@babel/preset-env'],
    ['@babel/preset-react'], // add this
  ],
  plugins: [
    ['@babel/plugin-syntax-jsx'],
    ['@babel/plugin-proposal-decorators', {
      legacy: true,
    }],
    ['@babel/plugin-proposal-class-properties', {
      legacy: true,
    }],
  ],
};
