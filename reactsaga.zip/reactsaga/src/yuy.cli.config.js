const path = require("path");

const ROOT_PATH = process.cwd();
const config = {
  beforeBuild: (callBack) => {
    callBack();
  },
  afterBuild: () => {},
  entry: [
    {
      src: path.resolve(ROOT_PATH, "./src/App.js"),
      html: path.resolve(ROOT_PATH, "./src/index.html"),
    },
  ],
  extractPublicCss: false,
  serverConfig: {
    port: 9001,
    hot: false,
    writeToDisk: false,
    publicPath: "/",
  },
  combine: {
    dev: {
      output: {
        path: path.resolve(ROOT_PATH, "dist"),
        filename: "assets/js/[name].js",
        libraryTarget: "umd",
      },
    },
    prd: {
      output: {
        path: path.resolve(ROOT_PATH, "dist"),
        filename: "assets/js/[name].js",
        libraryTarget: "umd",
      },
    },
  },
};

module.exports = {
  config,
};
