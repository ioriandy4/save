import React from "react";

function App() {
  return (
    <div className="App">
      <p>fuckww</p>
    </div>
  );
}

export default App;
